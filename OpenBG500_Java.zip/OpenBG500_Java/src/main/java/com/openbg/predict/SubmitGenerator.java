package com.openbg.predict;

import com.openbg.data.DataLoader;
import com.openbg.data.Triple;
import com.openbg.model.TransEModel;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class SubmitGenerator {
    private final TransEModel model;
    private final DataLoader dataLoader;

    // 构造函数
    public SubmitGenerator(TransEModel model, DataLoader dataLoader) {
        this.model = model;
        this.dataLoader = dataLoader;
    }

    // 生成提交文件
    public void generate(String submitPath) throws IOException {
        System.out.println("\n=== 生成提交文件 ===");
        File file = new File(submitPath);
        // 创建父文件夹
        File parent = file.getParentFile();
        if (!parent.exists()) parent.mkdirs();

        // 写入TSV文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            int count = 0;
            for (Triple triple : dataLoader.getTestTriples()) {
                String headId = triple.getHeadId();
                String relId = triple.getRelId();
                // 预测Top10尾实体
                List<String> top10Tails = model.predictTop10(
                        headId,
                        relId,
                        dataLoader.getEntity2Int(),
                        dataLoader.getRel2Int(),
                        dataLoader.getInt2Entity()
                );
                // 拼接成12列：head + rel + 10个tail（Tab分隔）
                String line = headId + "\t" + relId + "\t" + String.join("\t", top10Tails);
                writer.write(line);
                writer.newLine();
                count++;
            }
            System.out.println("已生成" + count + "条预测结果（12列格式），保存至：" + submitPath);
        }
    }
}
