package com.openbg;

import com.openbg.data.DataLoader;
import com.openbg.model.TransEModel;
import com.openbg.predict.SubmitGenerator;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        // 1. 配置路径
        String dataRoot = "E:\\OpenBG500_Java\\OpenBG500";  // 数据集根路径（放6个TSV文件）
        String submitPath = "E:\\OpenBG500_Java\\OpenBG500_test_pred.tsv";  // 提交文件输出路径

        // 2. 加载数据
        DataLoader dataLoader = new DataLoader(dataRoot);
        dataLoader.loadAllData();
        dataLoader.printChineseTripleExample(2);  // 验证数据加载

        // 3. 初始化TransE模型
        TransEModel transEModel = new TransEModel(
                dataLoader.getEntityCount(),
                dataLoader.getRelCount(),
                300,    // 嵌入维度
                2.0f,   // margin
                0.0005f, // 学习率
                0.001f, // 正则化参数
                0.95f   // 学习率衰减率
        );

        // 4. 训练模型
        transEModel.train(
                dataLoader.getTrainTriples(),
                5,    // 训练轮次
                256,    // 批次大小
                100     // 负样本数
        );

        // 5. 验证模型
        transEModel.evaluate(dataLoader.getDevTriples());

        // 6. 生成提交文件（12列格式）
        SubmitGenerator submitGenerator = new SubmitGenerator(transEModel, dataLoader);
        submitGenerator.generate(submitPath);

        System.out.println("\n全流程完成！提交文件路径：" + submitPath);
        System.out.println("将该文件可上传天池。");
    }
}
