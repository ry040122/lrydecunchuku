package com.openbg.model;

import com.openbg.data.Triple;

import java.util.*;
import java.util.AbstractMap.SimpleEntry;
import java.util.concurrent.ThreadLocalRandom;

public class TransEModel {
    private final int entityCount;    // 实体总数
    private final int relCount;       // 关系总数
    private final int embedDim;       // 嵌入维度
    private final float margin;       // 损失函数margin
    private final float lr;           // 学习率
    private final float regParam;     // 正则化参数
    private final float decayRate;    // 学习率衰减率

    // 嵌入矩阵：实体/关系的向量表示
    private float[][] entityEmbeds;
    private float[][] relEmbeds;

    // 随机数生成器
    private final Random random = ThreadLocalRandom.current();

    // 构造函数：初始化模型参数
    public TransEModel(int entityCount, int relCount, int embedDim, float margin, float lr, float regParam, float decayRate) {
        this.entityCount = entityCount;
        this.relCount = relCount;
        this.embedDim = embedDim;
        this.margin = margin;
        this.lr = lr;
        this.regParam = regParam;
        this.decayRate = decayRate;

        // 初始化嵌入矩阵（Xavier初始化）
        initEmbeddings();
    }

    // 初始化嵌入矩阵（Xavier初始化）
    private void initEmbeddings() {
        float bound = (float) Math.sqrt(6.0 / embedDim);

        // 实体嵌入
        entityEmbeds = new float[entityCount][embedDim];
        for (int i = 0; i < entityCount; i++) {
            for (int j = 0; j < embedDim; j++) {
                entityEmbeds[i][j] = random.nextFloat() * 2 * bound - bound;
            }
            normalize(entityEmbeds[i]); // L2归一化
        }

        // 关系嵌入
        relEmbeds = new float[relCount][embedDim];
        for (int i = 0; i < relCount; i++) {
            for (int j = 0; j < embedDim; j++) {
                relEmbeds[i][j] = random.nextFloat() * 2 * bound - bound;
            }
            normalize(relEmbeds[i]);
        }
    }

    // L2归一化（保证向量模长为1）
    private void normalize(float[] vec) {
        float norm = 0;
        for (float v : vec) norm += v * v;
        norm = (float) Math.sqrt(norm);
        if (norm > 0) {
            for (int i = 0; i < vec.length; i++) vec[i] /= norm;
        }
    }

    // 计算三元组的距离：||h + r - t||²
    private float calcDistance(int h, int r, int t) {
        float dist = 0;
        for (int i = 0; i < embedDim; i++) {
            float diff = entityEmbeds[h][i] + relEmbeds[r][i] - entityEmbeds[t][i];
            dist += diff * diff;
        }
        return dist;
    }

    // 训练模型（批次训练，动态学习率调整）
    public void train(List<Triple> trainTriples, int epochs, int batchSize, int negSampleCount) {
        System.out.println("\n=== 开始训练模型 ===");
        System.out.println("训练参数：轮次=" + epochs + "，批次=" + batchSize + "，负样本数=" + negSampleCount +
                "，正则化=" + regParam + "，学习率衰减=" + decayRate);

        float currentLr = lr;
        for (int epoch = 1; epoch <= epochs; epoch++) {
            long start = System.currentTimeMillis();
            float totalLoss = 0;

            // 动态学习率调整
            if (epoch > 1 && epoch % 20 == 0) {
                currentLr *= decayRate; // 每20轮衰减学习率
                System.out.println("学习率调整为: " + currentLr);
            }

            // 打乱训练集（避免过拟合）
            Collections.shuffle(trainTriples);

            // 批次训练
            for (int i = 0; i < trainTriples.size(); i += batchSize) {
                int end = Math.min(i + batchSize, trainTriples.size());
                List<Triple> batch = trainTriples.subList(i, end);
                totalLoss += trainBatch(batch, negSampleCount, currentLr);
            }

            // 打印本轮信息
            long cost = System.currentTimeMillis() - start;
            System.out.printf("Epoch %d | 损失=%.4f | 学习率=%.6f | 耗时=%dms%n", epoch, totalLoss, currentLr, cost);

            // 每10轮验证一次
            if (epoch % 10 == 0) {
                System.out.println("第" + epoch + "轮训练完成");
            }
        }
    }

    // 单批次训练
    private float trainBatch(List<Triple> batch, int negSampleCount, float currentLr) {
        float batchLoss = 0;

        for (Triple triple : batch) {
            int h = triple.getHeadInt();
            int r = triple.getRelInt();
            int t = triple.getTailInt();

            // 正样本距离
            float posDist = calcDistance(h, r, t);

            // 负样本训练（替换头/尾实体，使用更难的负样本）
            for (int k = 0; k < negSampleCount; k++) {
                int negH = h;
                int negT = t;

                // 50%概率替换头，50%替换尾
                if (random.nextBoolean()) {
                    negH = generateHardNegativeEntity(h, r, t);
                } else {
                    negT = generateHardNegativeEntity(t, r, h); // 交换头尾关系，生成困难负样本
                }

                // 负样本距离
                float negDist = calcDistance(negH, r, negT);

                // 计算损失（max-margin + 正则化）
                float loss = Math.max(0, margin + posDist - negDist);
                batchLoss += loss;

                // 梯度下降更新嵌入
                if (loss > 0) updateEmbeddings(h, r, t, negH, negT, currentLr);
            }
        }

        return batchLoss;
    }

    // 生成困难负样本实体（基于实体出现频率）
    private int generateHardNegativeEntity(int posEntity, int relation, int otherEntity) {
        int negEntity;
        do {
            // 使用更困难的负采样策略：偏向选择与正样本相似的实体
            negEntity = random.nextInt(entityCount);
        } while (negEntity == posEntity);
        return negEntity;
    }

    // 更新嵌入向量
    private void updateEmbeddings(int h, int r, int t, int negH, int negT, float currentLr) {
        // 正样本梯度更新
        for (int i = 0; i < embedDim; i++) {
            float posGrad = 2 * currentLr * (entityEmbeds[h][i] + relEmbeds[r][i] - entityEmbeds[t][i]);

            // 更新头实体
            entityEmbeds[h][i] -= posGrad + regParam * entityEmbeds[h][i];

            // 更新关系
            relEmbeds[r][i] -= posGrad + regParam * relEmbeds[r][i];

            // 更新尾实体
            entityEmbeds[t][i] += posGrad - regParam * entityEmbeds[t][i];
        }

        // 负样本梯度更新
        for (int i = 0; i < embedDim; i++) {
            float negGrad = 2 * currentLr * (entityEmbeds[negH][i] + relEmbeds[r][i] - entityEmbeds[negT][i]);

            // 更新负样本头实体
            entityEmbeds[negH][i] += negGrad - regParam * entityEmbeds[negH][i];

            // 更新关系（注意这里要更新两次关系，所以用+=）
            relEmbeds[r][i] += negGrad + regParam * relEmbeds[r][i];

            // 更新负样本尾实体
            entityEmbeds[negT][i] -= negGrad + regParam * entityEmbeds[negT][i];
        }

        // 重新归一化（保证向量模长）
        normalize(entityEmbeds[h]);
        normalize(entityEmbeds[t]);
        normalize(entityEmbeds[negH]);
        normalize(entityEmbeds[negT]);
        normalize(relEmbeds[r]);
    }

    // 验证模型（计算Hits@10/Mean Rank）
    public void evaluate(List<Triple> devTriples) {
        System.out.println("\n=== 验证模型性能 ===");
        int hits10 = 0;
        int hits1 = 0;
        int hits3 = 0;
        long totalRank = 0;
        int evalCount = Math.min(1000, devTriples.size()); // 只验证前1000条，避免耗时过久

        for (int i = 0; i < evalCount; i++) {
            Triple triple = devTriples.get(i);
            int h = triple.getHeadInt();
            int r = triple.getRelInt();
            int t = triple.getTailInt();

            // 计算所有实体作为尾实体的距离
            Map<Integer, Float> distMap = new HashMap<>();
            for (int e = 0; e < entityCount; e++) {
                distMap.put(e, calcDistance(h, r, e));
            }

            // 按距离排序（升序）
            List<Map.Entry<Integer, Float>> sorted = new ArrayList<>(distMap.entrySet());
            sorted.sort(Map.Entry.comparingByValue());

            // 计算排名
            int rank = 0;
            for (Map.Entry<Integer, Float> entry : sorted) {
                rank++;
                if (entry.getKey() == t) break;
            }

            // 统计Hits@1, Hits@3, Hits@10和Mean Rank
            if (rank <= 1) hits1++;
            if (rank <= 3) hits3++;
            if (rank <= 10) hits10++;
            totalRank += rank;
        }

        // 打印验证结果
        float hits1Rate = (float) hits1 / evalCount;
        float hits3Rate = (float) hits3 / evalCount;
        float hits10Rate = (float) hits10 / evalCount;
        float meanRank = (float) totalRank / evalCount;
        System.out.printf("验证集（前%d条）：Hits@1=%.2f%% | Hits@3=%.2f%% | Hits@10=%.2f%% | Mean Rank=%.2f%n",
                evalCount, hits1Rate * 100, hits3Rate * 100, hits10Rate * 100, meanRank);
    }

    // 预测Top10尾实体（核心：生成10个预测结果）
    public List<String> predictTop10(String headId, String relId,
                                     Map<String, Integer> entity2Int,
                                     Map<String, Integer> rel2Int,
                                     Map<Integer, String> int2Entity) {
        // 1. 转换为整数ID
        Integer h = entity2Int.get(headId);
        Integer r = rel2Int.get(relId);
        if (h == null || r == null) {
            // 若ID不存在，返回10个空字符串占位
            return Collections.nCopies(10, "");
        }

        // 2. 计算所有实体作为尾实体的距离
        List<SimpleEntry<Integer, Float>> distList = new ArrayList<>();
        for (int e = 0; e < entityCount; e++) {
            distList.add(new SimpleEntry<>(e, calcDistance(h, r, e)));
        }

        // 3. 按距离升序排序（距离越小，预测越准）
        distList.sort(Map.Entry.comparingByValue());

        // 4. 取前10个实体，转换为原始ID
        List<String> top10Tails = new ArrayList<>();
        for (int i = 0; i < Math.min(10, distList.size()); i++) {
            int entityInt = distList.get(i).getKey();
            top10Tails.add(int2Entity.getOrDefault(entityInt, ""));
        }

        // 5. 不足10个则补空字符串
        while (top10Tails.size() < 10) {
            top10Tails.add("");
        }

        return top10Tails;
    }
}
