package com.openbg.data;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class DataLoader {
    private final String dataRoot;  // 数据集根路径

    // 映射表：原始ID ↔ 整数ID
    private Map<String, Integer> entity2Int = new HashMap<>();
    private Map<String, Integer> rel2Int = new HashMap<>();
    private Map<Integer, String> int2Entity = new HashMap<>();

    // 中文映射表（仅调试用）
    private Map<String, String> entity2Text = new HashMap<>();
    private Map<String, String> rel2Text = new HashMap<>();

    // 数据集
    private List<Triple> trainTriples = new ArrayList<>();
    private List<Triple> devTriples = new ArrayList<>();
    private List<Triple> testTriples = new ArrayList<>();

    // 统计信息
    private Map<String, Integer> entityFrequency = new HashMap<>();
    private Map<String, List<String>> entityRelTailMap = new HashMap<>();
    private Map<String, List<String>> entityRelHeadMap = new HashMap<>();

    // 构造函数
    public DataLoader(String dataRoot) {
        this.dataRoot = dataRoot;
    }

    // 核心入口：加载所有数据
    public void loadAllData() throws IOException {
        System.out.println("=== 开始加载数据集 ===");
        loadEntity2Text();
        loadRel2Text();
        loadTrainTriples();
        loadDevTriples();
        loadTestTriples();
        buildIdMaps();
        updateTripleIntIds();
        deduplicateTrainTriples();
        buildStatistics();
        printDataStats();
    }

    // 读取实体→中文映射
    private void loadEntity2Text() throws IOException {
        File file = new File(dataRoot + "/OpenBG500_entity2text.tsv");
        if (!file.exists()) throw new IOException("实体映射文件不存在：" + file.getAbsolutePath());

        try (BufferedReader reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            CSVParser parser = CSVFormat.TDF.parse(reader);
            for (CSVRecord record : parser) {
                if (record.size() < 2) continue;
                String entityId = record.get(0).trim();
                String text = record.get(1).trim();
                if (!entityId.isEmpty() && !text.isEmpty()) entity2Text.put(entityId, text);
            }
        }
        System.out.println("已读取实体中文映射：" + entity2Text.size() + "条");
    }

    // 读取关系→中文映射
    private void loadRel2Text() throws IOException {
        File file = new File(dataRoot + "/OpenBG500_relation2text.tsv");
        if (!file.exists()) throw new IOException("关系映射文件不存在：" + file.getAbsolutePath());

        try (BufferedReader reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            CSVParser parser = CSVFormat.TDF.parse(reader);
            for (CSVRecord record : parser) {
                if (record.size() < 2) continue;
                String relId = record.get(0).trim();
                String text = record.get(1).trim();
                if (!relId.isEmpty() && !text.isEmpty()) rel2Text.put(relId, text);
            }
        }
        System.out.println("已读取关系中文映射：" + rel2Text.size() + "条");
    }

    // 读取训练集
    private void loadTrainTriples() throws IOException {
        File file = new File(dataRoot + "/OpenBG500_train.tsv");
        if (!file.exists()) throw new IOException("训练集不存在：" + file.getAbsolutePath());

        try (BufferedReader reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            CSVParser parser = CSVFormat.TDF.parse(reader);
            for (CSVRecord record : parser) {
                if (record.size() < 3) continue;
                String head = record.get(0).trim();
                String rel = record.get(1).trim();
                String tail = record.get(2).trim();
                if (!head.isEmpty() && !rel.isEmpty() && !tail.isEmpty()) {
                    trainTriples.add(new Triple(head, rel, tail));
                }
            }
        }
        System.out.println("已读取训练集原始数据：" + trainTriples.size() + "条");
    }

    // 读取验证集
    private void loadDevTriples() throws IOException {
        File file = new File(dataRoot + "/OpenBG500_dev.tsv");
        if (!file.exists()) throw new IOException("验证集不存在：" + file.getAbsolutePath());

        try (BufferedReader reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            CSVParser parser = CSVFormat.TDF.parse(reader);
            for (CSVRecord record : parser) {
                if (record.size() < 3) continue;
                String head = record.get(0).trim();
                String rel = record.get(1).trim();
                String tail = record.get(2).trim();
                if (!head.isEmpty() && !rel.isEmpty() && !tail.isEmpty()) {
                    devTriples.add(new Triple(head, rel, tail));
                }
            }
        }
        System.out.println("已读取验证集原始数据：" + devTriples.size() + "条");
    }

    // 读取测试集
    private void loadTestTriples() throws IOException {
        File file = new File(dataRoot + "/OpenBG500_test.tsv");
        if (!file.exists()) throw new IOException("测试集不存在：" + file.getAbsolutePath());

        try (BufferedReader reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            CSVParser parser = CSVFormat.TDF.parse(reader);
            for (CSVRecord record : parser) {
                if (record.size() < 2) continue;
                String head = record.get(0).trim();
                String rel = record.get(1).trim();
                if (!head.isEmpty() && !rel.isEmpty()) {
                    testTriples.add(new Triple(head, rel, ""));
                }
            }
        }
        System.out.println("已读取测试集原始数据：" + testTriples.size() + "条");
    }

    // 构建ID映射
    private void buildIdMaps() {
        Set<String> allEntities = new HashSet<>();
        for (Triple t : trainTriples) { allEntities.add(t.getHeadId()); allEntities.add(t.getTailId()); }
        for (Triple t : devTriples) { allEntities.add(t.getHeadId()); allEntities.add(t.getTailId()); }

        Set<String> allRels = new HashSet<>();
        for (Triple t : trainTriples) { allRels.add(t.getRelId()); }
        for (Triple t : devTriples) { allRels.add(t.getRelId()); }

        int idx = 0;
        for (String entity : allEntities) { entity2Int.put(entity, idx); int2Entity.put(idx++, entity); }
        idx = 0;
        for (String rel : allRels) { rel2Int.put(rel, idx++); }

        System.out.println("已构建ID映射：实体数=" + entity2Int.size() + "，关系数=" + rel2Int.size());
    }

    // 更新整数ID
    private void updateTripleIntIds() {
        List<Triple> validTrain = new ArrayList<>();
        for (Triple t : trainTriples) {
            Integer head = entity2Int.get(t.getHeadId());
            Integer rel = rel2Int.get(t.getRelId());
            Integer tail = entity2Int.get(t.getTailId());
            if (head != null && rel != null && tail != null) {
                t.setHeadInt(head); t.setRelInt(rel); t.setTailInt(tail);
                validTrain.add(t);
            }
        }
        trainTriples = validTrain;

        List<Triple> validDev = new ArrayList<>();
        for (Triple t : devTriples) {
            Integer head = entity2Int.get(t.getHeadId());
            Integer rel = rel2Int.get(t.getRelId());
            Integer tail = entity2Int.get(t.getTailId());
            if (head != null && rel != null && tail != null) {
                t.setHeadInt(head); t.setRelInt(rel); t.setTailInt(tail);
                validDev.add(t);
            }
        }
        devTriples = validDev;
    }

    // 训练集去重
    private void deduplicateTrainTriples() {
        Set<String> keys = new HashSet<>();
        List<Triple> unique = new ArrayList<>();
        for (Triple t : trainTriples) {
            String key = t.getHeadId() + "_" + t.getRelId() + "_" + t.getTailId();
            if (!keys.contains(key)) { keys.add(key); unique.add(t); }
        }
        trainTriples = unique;
        System.out.println("训练集去重后：" + trainTriples.size() + "条");
    }

    // 构建统计信息（用于优化负采样）
    private void buildStatistics() {
        // 统计实体出现频率
        for (Triple t : trainTriples) {
            entityFrequency.put(t.getHeadId(), entityFrequency.getOrDefault(t.getHeadId(), 0) + 1);
            entityFrequency.put(t.getTailId(), entityFrequency.getOrDefault(t.getTailId(), 0) + 1);
        }

        // 构建关系模式图
        for (Triple t : trainTriples) {
            // 实体 -> (关系, 尾实体) 映射
            String head = t.getHeadId();
            entityRelTailMap.computeIfAbsent(head, k -> new ArrayList<>()).add(t.getRelId() + "_" + t.getTailId());

            // 实体 -> (关系, 头实体) 映射
            String tail = t.getTailId();
            entityRelHeadMap.computeIfAbsent(tail, k -> new ArrayList<>()).add(t.getRelId() + "_" + t.getHeadId());
        }

        System.out.println("已构建统计信息：实体频率统计，关系模式映射");
    }

    // 打印统计
    private void printDataStats() {
        System.out.println("\n=== 数据加载完成 ===");
        System.out.println("实体总数：" + entity2Int.size());
        System.out.println("关系总数：" + rel2Int.size());
        System.out.println("训练集数量：" + trainTriples.size());
        System.out.println("验证集数量：" + devTriples.size());
        System.out.println("测试集数量：" + testTriples.size());
    }

    // 打印中文示例
    public void printChineseTripleExample(int count) {
        System.out.println("\n=== 中文三元组示例（前" + count + "条）===");
        int show = Math.min(count, trainTriples.size());
        for (int i = 0; i < show; i++) {
            Triple t = trainTriples.get(i);
            String head = entity2Text.getOrDefault(t.getHeadId(), t.getHeadId());
            String rel = rel2Text.getOrDefault(t.getRelId(), t.getRelId());
            String tail = entity2Text.getOrDefault(t.getTailId(), t.getTailId());
            System.out.printf("%d: [%s] <--> [%s] <--> [%s]%n", i+1, head, rel, tail);
        }
    }

    // Getter（对外提供数据）
    public List<Triple> getTrainTriples() { return trainTriples; }
    public List<Triple> getDevTriples() { return devTriples; }
    public List<Triple> getTestTriples() { return testTriples; }
    public Map<String, Integer> getEntity2Int() { return entity2Int; }
    public Map<String, Integer> getRel2Int() { return rel2Int; }
    public Map<Integer, String> getInt2Entity() { return int2Entity; }
    public int getEntityCount() { return entity2Int.size(); }
    public int getRelCount() { return rel2Int.size(); }

    // 用于负采样的辅助方法
    public Map<String, Integer> getEntityFrequency() { return entityFrequency; }
}
