package com.openbg.data;

// 三元组模型：存储原始ID和整数ID
public class Triple {
    // 原始ID（字符串）
    private String headId;
    private String relId;
    private String tailId;

    // 整数ID（模型训练用）
    private int headInt;
    private int relInt;
    private int tailInt;

    // 构造函数
    public Triple(String headId, String relId, String tailId) {
        this.headId = headId;
        this.relId = relId;
        this.tailId = tailId;
    }

    // Getter & Setter（完整）
    public String getHeadId() { return headId; }
    public void setHeadId(String headId) { this.headId = headId; }
    public String getRelId() { return relId; }
    public void setRelId(String relId) { this.relId = relId; }
    public String getTailId() { return tailId; }
    public void setTailId(String tailId) { this.tailId = tailId; }

    public int getHeadInt() { return headInt; }
    public void setHeadInt(int headInt) { this.headInt = headInt; }
    public int getRelInt() { return relInt; }
    public void setRelInt(int relInt) { this.relInt = relInt; }
    public int getTailInt() { return tailInt; }
    public void setTailInt(int tailInt) { this.tailInt = tailInt; }
}
